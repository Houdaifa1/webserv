# ifndef TOKEN_HPP
# define TOKEN_HPP

# include "Libraries.hpp"

enum    TokenType
{
    UNDEFINED,
    IDENTIFIER,
    SYMBOL,
    NUMBER,
    SIZE,
    PATH,
    COMMENT,
    END_OF_FILE,
};


class   Token
{
    private :

        TokenType   type;
        std::string value;
        int         line;
        int         col;
    
    public :

        Token();
        void set_new_token(const std::string &value, int col, int line, 
        TokenType type);
};


# endif