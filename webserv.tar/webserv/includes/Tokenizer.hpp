# ifndef TOKENIZER_HPP
# define TOKENIZER_HPP

# include "Token.hpp"

class Tokenizer
{
    private :
        
        std::string         file_name;
        std::string         config;
        std::vector<Token>  tokens;
        int                 index;
        int                 col;
        int                 line;
        char                c;

        int     tokenize_str();
        int     get_config_in_str();
        void    skip_void();
        void    is_comment();

    public :

        Tokenizer(char  *file_name);
        int Tokenizeall();
        void display_config();
  

};




# endif 