# include "../Tokenizer.hpp"

Tokenizer::Tokenizer(char   *file_name) : file_name(file_name), 
    index(0), col(1), line(1) {}

int Tokenizer::get_config_in_str()
{
    std::ifstream   file(file_name.c_str());
    if (!file.is_open())
        return (1);
    std::string     line;
    while (std::getline(file, line))
    {
        config += line;
        config += '\n';
    }
    return(0);
}

void Tokenizer::skip_void()
{
    if ((c >= 9 && c <= 13) || c == ' ' || c == '\n')
    {
        if (c == '\n')
        {
            col = 0;
            line++;
        }
        index++;
        col++;
    }
}

void Tokenizer::is_comment()
{
    if (c == '#')
    {
        std::string value;
        Token new_token;
        for ( ; index < config.size(); index++)
        {
            c = config[index];
            value += c;
            if (c == '\n')
            {
                line++;
                break ;
            }
        }
        new_token.set_new_token(value, col, line, COMMENT);
        tokens.push_back(new_token);
        col = 1;
    }
}

int Tokenizer::tokenize_str()
{
    if (config.empty())
    {
        std::cout << "Config file empty" << std::endl ;
        return 1;
    }
    for(index = 0; index < config.size(); index++)
    {
        c = config[index];
        skip_void();
        is_comment();
        
    }

}

int Tokenizer::Tokenizeall()
{
    get_config_in_str();
    tokenize_str();
    return(0);
}


void    Tokenizer::display_config()
{
    std::cout << config << std::endl;
}